 <!-- footer -->
 <div class="footer_agile_w3ls" style="padding: 5">
            
            
            
         <div class="container">
<!--                <div class="agileits_w3layouts_footer_grids">
                    <div class="col-md-3 footer-w3-agileits">
                        <h3>Training Grounds</h3>
                        <ul>
                            <li>Etiam quis placerat</li>
                            <li>the printing</li>
                            <li>unknown printer</li>
                            <li>Lorem Ipsum</li>
                        </ul>
                    </div>
                    <div class="col-md-3 footer-agileits">
                        <h3>Specialized</h3>
                        <ul>
                            <li>the printing</li>
                            <li>Etiam quis placerat</li>
                            <li>Lorem Ipsum</li>
                            <li>unknown printer</li>
                        </ul>
                    </div>
                    <div class="col-md-3 footer-wthree">
                        <h3>Partners</h3>
                        <ul>
                            <li>unknown printer</li>
                            <li>Lorem Ipsum</li>
                            <li>the printing</li>
                            <li>Etiam quis placerat</li>
                        </ul>
                    </div>

                    <div class="col-md-3 footer-agileits-w3layouts">
                        <h3>Our Links</h3>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><a href="about.html">About</a></li>
                            <li><a href="events.html">Events</a></li>
                            <li><a href="mail.html">Contact</a></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>

                </div>-->
                <div class="agileits_w3layouts_logo logo2">
                    <h2><a href="index.html">Community</a></h2>
                    <div class="agileits-social">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                            <li><a href="#"><i class="fa fa-vk"></i></a></li>
                        </ul>
                    </div>

                </div>
            </div>
            
            
            
            
        </div>
        <div class="wthree_copy_right">
            <div class="container">
                <p>© 2017 All rights reserved | Design by COMMU</p>
            </div>
        </div>
        <!-- //footer -->