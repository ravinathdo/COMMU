 <ul class="nav navbar-nav">
     <li ><a href="home.php"><span data-hover="Home">Home</span></a></li>
     <li><a href="admin_member_registration.php"><span data-hover="New Reg.">New Reg.</span></a></li>
                            <li><a href="admin_news.php"><span data-hover="News">News</span></a></li>
                            <li><a href="admin_post.php"><span data-hover="Post">Post</span></a></li>
                            <li><a href="admin_training.php"><span data-hover="Training">Training</span></a></li>
                           
                            <li class="dropdown">
                                <a href="" class="dropdown-toggle" data-toggle="dropdown"><span data-hover="Inventory">Inventory</span> <b class="caret"></b></a>
                                <ul class="dropdown-menu agile_short_dropdown">
                                    <li><a href="admin_manage_item.php">Manage Items</a></li>
                                    <!--<li><a href="admin_manage_inventory.php">List Inventory Request</a></li>-->
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="" class="dropdown-toggle" data-toggle="dropdown"><span data-hover="Election">Election</span> <b class="caret"></b></a>
                                <ul class="dropdown-menu agile_short_dropdown">
                                    <li><a href="admin_setup_election.php">Setup Election</a></li>
                                    <li><a href="admin_manage_election.php">Manage Election</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="" class="dropdown-toggle" data-toggle="dropdown"><span data-hover="Other">Other</span> <b class="caret"></b></a>
                                <ul class="dropdown-menu agile_short_dropdown">
                                    <li><a href="admin_member_fee_view.php">Fee</a></li>
                                </ul>
                            </li>
                            
                        </ul>