<li ><a href="index.php"><span data-hover="Home">Home</span></a></li>
<li><a href="about.php"><span data-hover="About Us">About Us</span></a></li>
<li><a href="events.php"><span data-hover="Events">Events</span></a></li>
<li><a href="news.php"><span data-hover="News">News</span></a></li>
<li><a href="downer.php"><span data-hover="Donor Volunteer">Donor/Volunteer</span></a></li>