<ul class="nav navbar-nav">
    <li ><a href="home.php"><span data-hover="Home">Home</span></a></li>
    <li><a href="member_post.php"><span data-hover="Post">Post</span></a></li>
    <li><a href="member_items_request.php"><span data-hover="Inventory">Inventory</span></a></li>
    <li><a href="manager_suggest_member.php"><span data-hover="Nominate">Nominate</span></a></li>
    <li ><a href="member_attendance.php"><span data-hover="Attendance">Attendance</span></a></li>
    <li ><a href="member_fee.php"><span data-hover="Member Fee">Fee</span></a></li>
    <li ><a href="member_training.php"><span data-hover=Training">Training</span></a></li>
<!--    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span data-hover="Inventory">Inventory</span> <b class="caret"></b></a>
        <ul class="dropdown-menu agile_short_dropdown">
            <li><a href="icons.html">Web Icons</a></li>
            <li><a href="typography.html">Typography</a></li>
        </ul>
    </li>-->
</ul>
