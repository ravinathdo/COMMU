<!--
author: Thisara
-->
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Commu</title>
        <!-- custom-theme -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Funding Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
            function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- //custom-theme -->

        <?php include_once './basecss.php'; ?>

    </head>	
    <body>
        <?php
        include './model/UserModel.php';
        if (isset($_POST['btnLogin'])) {

            $flag = doLogin();

            if ($flag) {
                // echo 'User Found';
                header('Location:home.php');
            } else {

                echo '<p class="bg-danger">Invalid Username or Password</p>';
            }
        }
        ?>
        <!-- banner -->
        <div class="header">

            <div class="w3layouts_header_right">
                <div class="agileits-social top_content">
                    <ul>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#"><i class="fa fa-vk"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="w3layouts_header_left">
                <ul>
                    <li><a href="#" data-toggle="modal" data-target="#myModal2">Community Management System</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#myModal2"><i class="fa fa-user" aria-hidden="true"></i> Sign in</a></li>
                    <!--<li><a href="#" data-toggle="modal" data-target="#myModal3"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Sign Up </a></li>-->
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>



        <div class="banner">
            <nav class="navbar navbar-default">
                <div class="navbar-header navbar-left">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1><a class="navbar-brand" href="index.html"><span>C</span>OMMU</a></h1>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                    <nav class="link-effect-2" id="link-effect-2">
                        <ul class="nav navbar-nav">
                            <?php include './_menu_common.php'; ?>
                            <!--                            <li class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span data-hover="Short Codes">Short Codes</span> <b class="caret"></b></a>
                                                            <ul class="dropdown-menu agile_short_dropdown">
                                                                <li><a href="icons.html">Web Icons</a></li>
                                                                <li><a href="typography.html">Typography</a></li>
                                                            </ul>
                                                        </li>-->
                            <!--<li><a href="#"><span data-hover="Mail Us">Mail Us</span></a></li>-->
                        </ul>
                    </nav>

                </div>
                <div class="w3_agile_search">
                    <?php
                    include '_search.php';
                    ?>
                </div>
            </nav>
        </div>



        <div class = "header_mid">
            <div class = "w3layouts_header_mid">
                <ul>
                    <li>
                        <div class = "header_contact_details_agile"><i class = "fa fa-envelope-o" aria-hidden = "true"></i>
                            <div class = "w3l_header_contact_details_agile">
                                <div class = "header-contact-detail-title">Send us a Message</div>
                                <a href = "mailto:info@commu.com">info@commu.com</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class = "header_contact_details_agile"><i class = "fa fa-phone" aria-hidden = "true"></i>
                            <div class = "w3l_header_contact_details_agile">
                                <div class = "header-contact-detail-title">Give us a Call</div>
                                <a class = "w3l_header_contact_details_agile-info_inner"> 071-468-3414 </a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class = "header_contact_details_agile"><i class = "fa fa-clock-o" aria-hidden = "true"></i>
                            <div class = "w3l_header_contact_details_agile">
                                <div class = "header-contact-detail-title">Opening Hours</div>
                                <a class = "w3l_header_contact_details_agile-info_inner">Mon - Sat: 7:00 - 18:00</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class = "header_contact_details_agile"><i class = "fa fa-map-marker" aria-hidden = "true"></i>
                            <div class = "w3l_header_contact_details_agile">
                                <div class = "header-contact-detail-title">POBOX 3007 Union Place</div>
                                <a class = "w3l_header_contact_details_agile-info_inner">Sri Lanka, Colombo 03 </a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>






        <!-- courses -->
        <div class="team">
            <div class="container"> 
                <div class="w3_agile_team_grid">
                    <div class="w3_agile_team_grid_left">
                        <h3 class="w3l_header w3_agileits_header">About <span>US</span></h3>
                        <p class="sub_para_agile">
                            The Sri Lanka Red Cross Society has operated since 1936, first as a branch of the British Red Cross and then from 1949 to 1971 as the Ceylon Red Cross Society. It was recognized by the ICRC and admitted into the League of Red Cross Societies (now the International Federation of Red Cross & Red Crescent Societies) in 1952. The Ceylon Red Cross Society was renamed as Sri Lanka Red Cross Society in 1972. The society was recognized by Royal Charter in 1951 and as a charitable organization also in the same year by a gazette notification of the Finance Ministry. It was also registered under the Social Service Act 33 of 1980.

                            In 2002, SLRCS adopted a new constitution and organizational changes. The current management structure includes a Director General, three Deputy Director Generals for HR, finance and operations, and directors/executive directors of administration, finance, disaster management, communication, human resource development, and organizational development.

                            The SLRCS covers all 25 administrative Districts of the country and has 25 branches.

                            SLRCS Intention is to ensure that all activities, projects and programmes planned and implemented in the mid to long term by the various components of the Red Cross and Red Crescent Movement are carried out in full respect of the spirit of the Seville Agreement, and the 2010 Strategy for the Movement. A Tripartite Memorandum of Understanding signed in March 2003 between the SLRCS, the Federation and the ICRC, acts as a guide in all its partnership formations.

                            Movement support of the SLRCS has been strengthened by the conclusion of an International Federation Status Agreement with the GoSL in 2004.

                            The total membership 100,000. The total number of active volunteers 6,500

                        </p><br>

                        <h3 class="w3l_header w3_agileits_header">Vision <span></span></h3>

                        <p class="sub_para_agile">
                            Safer, resilient and socially inclusive communities through improving lifestyles and changing mind-sets.
                        </p>
                        <h3 class="w3l_header w3_agileits_header">Mission <span></span></h3>

                        <p class="sub_para_agile">
                           Reduce risk, build capacity and promote principles and values by mobilizing resources, creating universal access to services through volunteerism and partnership
                        </p>

                    </div>
                </div>
            </div>
        </div>
        <!-- //courses -->









        <!-- footer -->
        <?php include './_footer.php'; ?>
        <!-- //footer -->




        <!-- Modal1 -->
        <div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                        <div class="signin-form profile">
                            <h3 class="agileinfo_sign">Sign In</h3>	
                            <div class="login-form">
                                <form action="index.php" method="post">
                                    <input type="text" name="username" placeholder="Username" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <div class="tp">
                                        <input type="submit" name="btnLogin" value="Sign In">
                                    </div>
                                </form>
                            </div>
                            <div class="login-social-grids">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-rss"></i></a></li>
                                </ul>
                            </div>
                            <!--<p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //Modal1 -->	
        <!-- Modal2 -->
        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                        <div class="signin-form profile">
                            <h3 class="agileinfo_sign">Sign Up</h3>	
                            <div class="login-form">
                                <form action="#" method="post">
                                    <input type="text" name="name" placeholder="Username" required="">
                                    <input type="email" name="email" placeholder="Email" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="password" name="password" placeholder="Confirm Password" required="">
                                    <input type="submit" value="Sign Up">
                                </form>
                            </div>
                            <p><a href="#"> By clicking register, I agree to your terms</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //Modal2 -->	

        <!-- //bootstrap-pop-up -->

        <!-- js -->
        <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
        <!-- //js -->
        <!-- Counter required files -->
        <script type="text/javascript" src="js/dscountdown.min.js"></script>
        <script src="js/demo-1.js"></script>
        <script>
            jQuery(document).ready(function ($) {
                $('.demo2').dsCountDown({
                    endDate: new Date("December 24, 2020 23:59:00"),
                    theme: 'black'
                });
            });
        </script>
        <!-- //Counter required files -->



        <script src="js/mainScript.js"></script>
        <script src="js/rgbSlide.min.js"></script>
        <!-- carousal -->
        <script src="js/slick.js" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript">
            $(document).on('ready', function () {
                $(".center").slick({
                    dots: true,
                    infinite: true,
                    centerMode: true,
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    responsive: [
                        {
                            breakpoint: 768,
                            settings: {
                                arrows: true,
                                centerMode: false,
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                arrows: true,
                                centerMode: false,
                                centerPadding: '40px',
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            });
        </script>
        <!-- //carousal -->
        <!-- flexisel -->
        <script type="text/javascript">
            $(window).load(function () {
                $("#flexiselDemo1").flexisel({
                    visibleItems: 4,
                    animationSpeed: 1000,
                    autoPlay: true,
                    autoPlaySpeed: 3000,
                    pauseOnHover: true,
                    enableResponsiveBreakpoints: true,
                    responsiveBreakpoints: {
                        portrait: {
                            changePoint: 480,
                            visibleItems: 1
                        },
                        landscape: {
                            changePoint: 640,
                            visibleItems: 2
                        },
                        tablet: {
                            changePoint: 768,
                            visibleItems: 2
                        }
                    }
                });

            });
        </script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
        <!-- //flexisel -->
        <!-- gallery-pop-up -->
        <script src="js/lsb.min.js"></script>
        <script>
            $(window).load(function () {
                $.fn.lightspeedBox();
            });
        </script>
        <!-- //gallery-pop-up -->
        <!-- flexSlider -->
        <script defer src="js/jquery.flexslider.js"></script>
        <script type="text/javascript">
            $(window).load(function () {
                $('.flexslider').flexslider({
                    animation: "slide",
                    start: function (slider) {
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
        <!-- //flexSlider -->

        <!-- start-smooth-scrolling -->
        <script type="text/javascript" src="js/move-top.js"></script>
        <script type="text/javascript" src="js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $(".scroll").click(function (event) {
                    event.preventDefault();
                    $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
                });
            });
        </script>
        <!-- start-smooth-scrolling -->
        <!-- for bootstrap working -->
        <script src="js/bootstrap.js"></script>
        <!-- //for bootstrap working -->
        <!-- here stars scrolling icon -->
        <script type="text/javascript">
            $(document).ready(function () {
                /*
                 var defaults = {
                 containerID: 'toTop', // fading element id
                 containerHoverID: 'toTopHover', // fading element hover id
                 scrollSpeed: 1200,
                 easingType: 'linear' 
                 };
                 */

                $().UItoTop({easingType: 'easeOutQuart'});

            });
        </script>
        <!-- //here ends scrolling icon -->
    </body>
</html>