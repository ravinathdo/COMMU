 
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
        <link rel="stylesheet" href="css/mainStyles.css" />
        <link rel='stylesheet' href='css/dscountdown.css' type='text/css' media='all' />

        <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
        <!-- gallery -->
        <link href="css/lsb.css" rel="stylesheet" type="text/css">
        <!-- //gallery -->
        <!-- font-awesome-icons -->
        <link href="css/font-awesome.css" rel="stylesheet"> 
        <!--<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700,900" rel="stylesheet">-->

          <!-- datatable -->
          <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
          
     