<?php 
    include './model/DB.php';
    echo 'test db';
    getDBConnection();
    echo 'test db finish';
?>